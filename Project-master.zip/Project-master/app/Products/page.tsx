

'use client'

import Card from "./components/card/Card"

export default function Home() {
  return (
    <>
    <div>      
    <Card/>
    </div>
    </>
  )
}
